package com.alp.modelo;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "roles")
public class Rol implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	// @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idRol;
	@Column(name = "tipoRol", length = 45)
	private String tipoRol;

	@OneToMany(targetEntity = Usuario.class, mappedBy = "idRol")
	private List<Usuario> listaUsuario;

	@ManyToMany(cascade = { CascadeType.MERGE })
	@JoinTable(name = "rolpermiso", joinColumns = @JoinColumn(name = "idRol", nullable = false), inverseJoinColumns = @JoinColumn(name = "idPermiso", nullable = false))
	private List<Permiso> listaPermiso;

	public int getIdRol() {
		return idRol;
	}

	public void setIdRol(int idRol) {
		this.idRol = idRol;
	}

	public String getTipoRol() {
		return tipoRol;
	}

	public void setTipoRol(String tipoRol) {
		this.tipoRol = tipoRol;
	}

	public List<Usuario> getListaUsuario() {
		return listaUsuario;
	}

	public void setListaUsuario(List<Usuario> listaUsuario) {
		this.listaUsuario = listaUsuario;
	}

	public List<Permiso> getListaPermiso() {
		return listaPermiso;
	}

	public void setListaPermiso(List<Permiso> listaPermiso) {
		this.listaPermiso = listaPermiso;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
