package com.alp.imp;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.alp.fachada.IDescuento;
import com.alp.modelo.CarroCompra;
import com.alp.modelo.Descuento;
import com.alp.utilities.JPAUtil;

public class DescuentoImp implements IDescuento {
	EntityManager entity = JPAUtil.getEntityManagerFactory().createEntityManager();
	@Override
	public List<Descuento> findAll() {
		this.entity.getTransaction().begin();	
		List<Descuento> listaDescuento= new ArrayList<>();
		Query q = this.entity.createQuery("SELECT dd FROM Descuento dd");
		listaDescuento = q.getResultList();
		this.entity.getTransaction();
		return listaDescuento;
	}

	@Override
	public Descuento findById(int idDescuento) {
		this.entity.getTransaction().begin();	
		Descuento descuento = new Descuento();
		descuento= this.entity.find(Descuento.class, idDescuento);
		
		return descuento;
	}

	@Override
	public void CrearDescuento(Descuento descuento) {
		this.entity.getTransaction().begin();
		this.entity.persist(descuento);
		this.entity.getTransaction().commit();

	}

	@Override
	public void ActualizarDescuento(Descuento descuento) {
		this.entity.getTransaction().begin();
		this.entity.merge(descuento);
		this.entity.getTransaction().commit();

	}

	@Override
	public void EliminarDescuento(int idDescuento) {
		Descuento descuento = new Descuento();
		descuento =this.entity.find(Descuento.class, idDescuento);
		
		this.entity.getTransaction().begin();
		this.entity.remove(descuento);
		this.entity.getTransaction().commit();

	}

}
