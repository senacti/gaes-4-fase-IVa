package com.alp.fachada;

import java.util.List;

import com.alp.modelo.CarroCompra;

public interface ICarroCompra {
	public List<CarroCompra> findAll();
	public CarroCompra findById (int idCarro);
	public void CrearCarroCompra (CarroCompra tipodocumento);
	public void ActualizarCarroCompra (CarroCompra tipodocumento);
	public void EliminarCarroCompra (int idCarro);

}
