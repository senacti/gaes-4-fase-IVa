package com.alp.fachada;

import java.util.List;

import com.alp.modelo.Permiso;

public interface IPermiso {
	public List<Permiso> findAll();
	public Permiso findById (int idPermiso);
	public void CrearPermiso (Permiso permiso);
	public void ActualizarPermiso(Permiso permiso);
	public void EliminarPermiso (int idPermiso);

}
