package com.alp.fachada;

import java.util.List;

import com.alp.modelo.Domicilio;

public interface IDomicilio {
	public List<Domicilio> findAll();
	public Domicilio findById (int idDomicilio);
	public void CrearDomicilio (Domicilio domicilio);
	public void ActualizarDomicilio (Domicilio domicilio);
	public void EliminarDomicilio (int idDomicilio);

}
