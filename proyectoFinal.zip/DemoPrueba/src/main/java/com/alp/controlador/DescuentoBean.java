package com.alp.controlador;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;

import com.alp.imp.DescuentoImp;
import com.alp.modelo.Descuento;

@ManagedBean (name="descuentoBean")
@RequestScoped
public class DescuentoBean {
Descuento descuento = new Descuento();
	
	List<Descuento> listaDescuento = new ArrayList<Descuento>();
	
	private Map<String,Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();		
	
	
	public Descuento getDescuento() {
		return descuento;
	}

	public void setDescuento(Descuento descuento) {
		this.descuento = descuento;
	}

	public List<Descuento> getListaDescuento() {
		return listaDescuento;
	}

	public void setListaDescuento(List<Descuento> listaDescuento) {
		this.listaDescuento = listaDescuento;
	}

	public Map<String, Object> getSessionMap() {
		return sessionMap;
	}

	public void setSessionMap(Map<String, Object> sessionMap) {
		this.sessionMap = sessionMap;
	}

	public List<Descuento> findAll(){
		
		DescuentoImp descuentoImp = new DescuentoImp();
		this.listaDescuento=  descuentoImp.findAll();
		return this.listaDescuento;
	}

	public String crear(Descuento descuento) {
		DescuentoImp descuentoImp = new DescuentoImp();
		descuentoImp.CrearDescuento(descuento);
		return "/descuento/lista.xhtml?faces-redirect=true";
	}
	
    public String findById(int idDescuento) {
		System.out.print("Entro a crear"+ idDescuento );
		DescuentoImp descuentoImp = new DescuentoImp();
		descuento = descuentoImp.findById(idDescuento);
		this.sessionMap.put("descuento", descuento);
		return "/descuento/editar.xhtml?faces-redirect=true";
    	
    }
    
	public String actualizar (Descuento descuento) {
		System.out.print("Ha entrado a EDITAR");
    	DescuentoImp descuentoImp = new DescuentoImp();
        descuentoImp.ActualizarDescuento(descuento);
        return "/descuento/lista.xhtml?faces-redirect=true";
    }
	
	public String eliminar (int idDescuento) {
		DescuentoImp descuentoImp = new DescuentoImp();
		descuentoImp.EliminarDescuento(idDescuento);
		System.out.print("Ha ELIMINADO");
		return "/descuento/lista.xhtml?faces-redirect=true";
	}

}