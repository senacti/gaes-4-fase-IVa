package com.alp.controlador;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;

import com.alp.imp.TipoDocumentoImp;
import com.alp.modelo.TipoDocumento;

@ManagedBean (name="tipodocumentoBean")
@RequestScoped
public class TipoDocumentoBean {
TipoDocumento tipodocumento = new TipoDocumento();
	
	List<TipoDocumento> listaTipodocumento = new ArrayList<TipoDocumento>();
	
	private Map<String,Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();		
	
	
	public TipoDocumento getTipodocumento() {
		return tipodocumento;
	}

	public void setTipodocumento(TipoDocumento tipodocumento) {
		this.tipodocumento = tipodocumento;
	}

	public List<TipoDocumento> getListaTipodocumento() {
		return listaTipodocumento;
	}

	public void setListaTipodocumento(List<TipoDocumento> listaTipodocumento) {
		this.listaTipodocumento = listaTipodocumento;
	}

	public Map<String, Object> getSessionMap() {
		return sessionMap;
	}

	public void setSessionMap(Map<String, Object> sessionMap) {
		this.sessionMap = sessionMap;
	}

	public List<TipoDocumento> findAll(){
		
		TipoDocumentoImp tipodocumentoImp = new TipoDocumentoImp();
		this.listaTipodocumento=  tipodocumentoImp.findAll();
		return this.listaTipodocumento;
	}

	public String crear(TipoDocumento tipodocumento) {
		TipoDocumentoImp tipodocumentoImp = new TipoDocumentoImp();
		tipodocumentoImp.CrearTipodocumento(tipodocumento);
		return "/tipodocumento/lista.xhtml?faces-redirect=true";
	}
	
    public String findById(int idDoc) {
		System.out.print("Entro a crear"+ idDoc );
		TipoDocumentoImp tipodocumentoImp = new TipoDocumentoImp();
		tipodocumento = tipodocumentoImp.findById(idDoc);
		this.sessionMap.put("tipodocumento", tipodocumento);
		return "/tipodocumento/editar.xhtml?faces-redirect=true";
    	
    }
    
	public String actualizar (TipoDocumento tipoDocumento) {
		System.out.print("Ha entrado a EDITAR");
    	TipoDocumentoImp tipodocumentoImp = new TipoDocumentoImp();
        tipodocumentoImp.ActualizarTipodocumento(tipoDocumento);
        return "/tipodocumento/lista.xhtml?faces-redirect=true";
    }
	
	public String eliminar (int idDoc) {
		TipoDocumentoImp tipodocumentoImp = new TipoDocumentoImp();
		tipodocumentoImp.EliminarTipodocumento(idDoc);
		System.out.print("Ha ELIMINADO");
		return "/tipodocumento/lista.xhtml?faces-redirect=true";
	}

}
