package com.alp.imp;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.alp.fachada.ICarroCompra;
import com.alp.modelo.CarroCompra;
import com.alp.modelo.TipoDocumento;
import com.alp.utilities.JPAUtil;

public class CarroCompraImp implements ICarroCompra {
	EntityManager entity = JPAUtil.getEntityManagerFactory().createEntityManager();
	@Override
	public List<CarroCompra> findAll() {
		this.entity.getTransaction().begin();	
		List<CarroCompra> listaCarroCompra= new ArrayList<>();
		Query q = this.entity.createQuery("SELECT c FROM TipoDocumento c");
		listaCarroCompra = q.getResultList();
		this.entity.getTransaction();
		return listaCarroCompra;
	}

	@Override
	public CarroCompra findById(int idCarro) {
		this.entity.getTransaction().begin();	
		CarroCompra carrocompra = new CarroCompra();
		carrocompra= this.entity.find(CarroCompra.class, idCarro);
		
		return carrocompra;
	}

	@Override
	public void CrearCarroCompra(CarroCompra carrocompra) {
		this.entity.getTransaction().begin();
		this.entity.persist(carrocompra);
		this.entity.getTransaction().commit();

	}

	@Override
	public void ActualizarCarroCompra(CarroCompra carrocompra) {
		this.entity.getTransaction().begin();
		this.entity.merge(carrocompra);
		this.entity.getTransaction().commit();

	}

	@Override
	public void EliminarCarroCompra(int idCarro) {
		CarroCompra carrocompra = new CarroCompra();
		carrocompra =this.entity.find(CarroCompra.class, idCarro);
		
		this.entity.getTransaction().begin();
		this.entity.remove(carrocompra);
		this.entity.getTransaction().commit();

	}

}


