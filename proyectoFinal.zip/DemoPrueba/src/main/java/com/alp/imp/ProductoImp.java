package com.alp.imp;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.alp.fachada.IProducto;
import com.alp.modelo.CarroCompra;
import com.alp.modelo.Producto;
import com.alp.utilities.JPAUtil;

public class ProductoImp implements IProducto {
	EntityManager entity = JPAUtil.getEntityManagerFactory().createEntityManager();
	@Override
	public List<Producto> findAll() {
		this.entity.getTransaction().begin();	
		List<Producto> listaProducto= new ArrayList<>();
		Query q = this.entity.createQuery("SELECT p FROM Producto p");
		listaProducto = q.getResultList();
		this.entity.getTransaction();
		return listaProducto;
	}

	@Override
	public Producto findById(int idProducto) {
		this.entity.getTransaction().begin();	
		Producto producto = new Producto();
		producto= this.entity.find(Producto.class, idProducto);
		
		return producto;
	}

	@Override
	public void CrearProducto(Producto producto) {
		this.entity.getTransaction().begin();
		this.entity.persist(producto);
		this.entity.getTransaction().commit();

	}

	@Override
	public void ActualizarProducto(Producto producto) {
		this.entity.getTransaction().begin();
		this.entity.persist(producto);
		this.entity.getTransaction().commit();

	}

	@Override
	public void EliminarProducto(int idProducto) {
		Producto producto = new Producto();
		producto =this.entity.find(Producto.class, idProducto);
		
		this.entity.getTransaction().begin();
		this.entity.remove(producto);
		this.entity.getTransaction().commit();

	}

}
