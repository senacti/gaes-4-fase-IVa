package com.alp.imp;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.alp.fachada.IRol;
import com.alp.modelo.CarroCompra;
import com.alp.modelo.Rol;
import com.alp.utilities.JPAUtil;

public class RolImp implements IRol {
	EntityManager entity = JPAUtil.getEntityManagerFactory().createEntityManager();
	@Override
	public List<Rol> findAll() {
		this.entity.getTransaction().begin();	
		List<Rol> listaRol= new ArrayList<>();
		Query q = this.entity.createQuery("SELECT rr FROM Rol rr");
		listaRol = q.getResultList();
		this.entity.getTransaction();
		return listaRol;
	}

	@Override
	public Rol findById(int idRol) {
		this.entity.getTransaction().begin();	
		Rol rol = new Rol();
		rol= this.entity.find(Rol.class, idRol);
		
		return rol;
	}

	@Override
	public void CrearRol(Rol rol) {
		this.entity.getTransaction().begin();
		this.entity.persist(rol);
		this.entity.getTransaction().commit();

	}

	@Override
	public void ActualizarRol(Rol rol) {
		this.entity.getTransaction().begin();
		this.entity.persist(rol);
		this.entity.getTransaction().commit();

	}

	@Override
	public void EliminarRol(int idRol) {
		Rol rol = new Rol();
		rol =this.entity.find(Rol.class, idRol);
		
		this.entity.getTransaction().begin();
		this.entity.remove(rol);
		this.entity.getTransaction().commit();

	}

	

}
