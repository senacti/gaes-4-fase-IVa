package com.alp.controlador;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;

import com.alp.imp.TipoDocumentoImp;
import com.alp.imp.UsuarioImp;
import com.alp.modelo.TipoDocumento;
import com.alp.modelo.Usuario;

@ManagedBean (name="usuarioBean")
@RequestScoped
public class UsuarioBean {
	Usuario usuario = new Usuario();
	
	List<Usuario> listaUsuario = new ArrayList<Usuario>();
	
	private Map<String,Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public List<Usuario> getListaUsuario() {
		return listaUsuario;
	}

	public void setListaUsuario(List<Usuario> listaUsuario) {
		this.listaUsuario = listaUsuario;
	}

	public Map<String, Object> getSessionMap() {
		return sessionMap;
	}

	public void setSessionMap(Map<String, Object> sessionMap) {
		this.sessionMap = sessionMap;
	}	
public List<Usuario> findAll(){
		
	UsuarioImp usuarioImp = new UsuarioImp();
		this.listaUsuario=  usuarioImp.findAll();
		return this.listaUsuario;
	}

	public String crear(Usuario usuario) {
		UsuarioImp usuarioImp = new UsuarioImp();
		usuarioImp.CrearUsuario(usuario);
		return "/usuario/lista.xhtml?faces-redirect=true";
	}
	
    public String findById(int idUsuario) {
		System.out.print("Entro a crear"+ idUsuario );
		UsuarioImp usuarioImp = new UsuarioImp();
		usuario= usuarioImp.findById(idUsuario);
		this.sessionMap.put("usuario", usuario);
		return "/Usuario/editar.xhtml?faces-redirect=true";
    	
    }
    
	public String actualizar (Usuario usuario) {
		System.out.print("Ha entrado a EDITAR");
		UsuarioImp usuarioImp = new UsuarioImp();
		usuarioImp.ActualizarUsuario(usuario);
        return "/Usuario/lista.xhtml?faces-redirect=true";
    }
	
	public String eliminar (int idUsuario) {
		UsuarioImp usuarioImp = new UsuarioImp();
		usuarioImp.EliminarUsuario(idUsuario);
		System.out.print("Ha ELIMINADO");
		return "/usuario/lista.xhtml?faces-redirect=true";
	}
	
}	
	