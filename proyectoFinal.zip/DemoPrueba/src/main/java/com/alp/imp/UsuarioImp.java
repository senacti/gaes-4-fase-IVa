package com.alp.imp;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.alp.fachada.IUsuario;
import com.alp.modelo.CarroCompra;
import com.alp.modelo.Usuario;
import com.alp.utilities.JPAUtil;

public class UsuarioImp implements IUsuario {
	EntityManager entity = JPAUtil.getEntityManagerFactory().createEntityManager();
	@Override
	public List<Usuario> findAll() {
		this.entity.getTransaction().begin();	
		List<Usuario> listaUsuario= new ArrayList<>();
		Query q = this.entity.createQuery("SELECT uu FROM Usuario uu");
		listaUsuario = q.getResultList();
		this.entity.getTransaction();
		return listaUsuario;
	}

	@Override
	public Usuario findById(int idUsuario) {
		this.entity.getTransaction().begin();	
		Usuario usuario = new Usuario();
		usuario= this.entity.find(Usuario.class, idUsuario);
		
		return usuario;
	}

	@Override
	public void CrearUsuario(Usuario usuario) {
		this.entity.getTransaction().begin();
		this.entity.merge(usuario);
		this.entity.getTransaction().commit();

	}

	@Override
	public void ActualizarUsuario(Usuario usuario) {
		this.entity.getTransaction().begin();
		this.entity.merge(usuario);
		this.entity.getTransaction().commit();

	}

	@Override
	public void EliminarUsuario(int idUsuario) {
		Usuario usuario = new Usuario();
		usuario =this.entity.find(Usuario.class, idUsuario);
		
		this.entity.getTransaction().begin();
		this.entity.remove(usuario);
		this.entity.getTransaction().commit();

	}

}
