package com.alp.fachada;

import java.util.List;

import com.alp.modelo.Proveedor;

public interface IProveedor {
	public List<Proveedor> findAll();
	public Proveedor findById (int idProveedor);
	public void CrearProvedor (Proveedor provedor);
	public void ActualizarProvedor(Proveedor provedor);
	public void EliminarProvedor (int idProveedor);

}
