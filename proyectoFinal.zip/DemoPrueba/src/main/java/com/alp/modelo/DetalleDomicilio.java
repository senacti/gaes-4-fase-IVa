package com.alp.modelo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "detallesdomicilio")
public class DetalleDomicilio implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	private int id;
	@Column(name = "estado", length = 45)
	private String estado;
	@Column(name = "direccion", length = 45)
	private String direccion;
	@Column(name = "telefono")
	private String telefono;
	@ManyToOne
	@JoinColumn(name = "idDomicilio")
	private Domicilio idDomicilio;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	public String getTelefono() {
		return telefono;
	}
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
	public Domicilio getIdDomicilioFk() {
		return idDomicilio;
	}
	public void setIdDomicilioFk(Domicilio idDomicilioFk) {
		this.idDomicilio = idDomicilio;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
