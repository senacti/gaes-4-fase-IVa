package com.alp.modelo;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "carrocompras")
public class CarroCompra implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	private int idCarro;
	@Column(name = "precio")
	private String precio;
	@Column(name = "cantidad")
	private String cantidad;
	@Column(name = "cantidadPagar")
	private String cantidadPagar;
	@Column(name = "estado", length = 45)
	private String estado;
	@ManyToOne
	@JoinColumn(name = "idUsuario")
	private Usuario idUsuario;


	@ManyToMany(cascade = { CascadeType.MERGE })
	@JoinTable(name = "carropro", joinColumns = @JoinColumn(name = "idCarro", nullable = false), inverseJoinColumns = @JoinColumn(name = "idProducto", nullable = false))
	private List<Producto> listaProducto;

	@OneToMany(targetEntity = Domicilio.class, mappedBy = "idCarro")
	private List<Domicilio> listaDomicilio;

	public int getIdCarro() {
		return idCarro;
	}

	public void setIdCarro(int idCarro) {
		this.idCarro = idCarro;
	}

	public String getPrecio() {
		return precio;
	}

	public void setPrecio(String precio) {
		this.precio = precio;
	}

	public String getCantidad() {
		return cantidad;
	}

	public void setCantidad(String cantidad) {
		this.cantidad = cantidad;
	}

	public String getCantidadPagar() {
		return cantidadPagar;
	}

	public void setCantidadPagar(String cantidadPagar) {
		this.cantidadPagar = cantidadPagar;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public Usuario getIdUsuarioFk() {
		return idUsuario;
	}

	public void setIdUsuarioFk(Usuario idUsuario) {
		this.idUsuario = idUsuario;
	}

	public List<Producto> getListaProducto() {
		return listaProducto;
	}

	public void setListaProducto(List<Producto> listaProducto) {
		this.listaProducto = listaProducto;
	}

	public List<Domicilio> getListaDomicilio() {
		return listaDomicilio;
	}

	public void setListaDomicilio(List<Domicilio> listaDomicilio) {
		this.listaDomicilio = listaDomicilio;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
    
}
