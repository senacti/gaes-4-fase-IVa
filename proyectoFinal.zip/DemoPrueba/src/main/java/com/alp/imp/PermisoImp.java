package com.alp.imp;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.alp.fachada.IPermiso;
import com.alp.modelo.CarroCompra;
import com.alp.modelo.Permiso;
import com.alp.utilities.JPAUtil;

public class PermisoImp implements IPermiso {
	EntityManager entity = JPAUtil.getEntityManagerFactory().createEntityManager();
	@Override
	public List<Permiso> findAll() {
		this.entity.getTransaction().begin();	
		List<Permiso> listaPermiso= new ArrayList<>();
		Query q = this.entity.createQuery("SELECT pp FROM Permiso pp");
		listaPermiso = q.getResultList();
		this.entity.getTransaction();
		return listaPermiso;
	}

	@Override
	public Permiso findById(int idPermiso) {
		this.entity.getTransaction().begin();	
		Permiso permiso = new Permiso();
		permiso= this.entity.find(Permiso.class, idPermiso);
		
		return permiso;
	}

	@Override
	public void CrearPermiso(Permiso permiso) {
		this.entity.getTransaction().begin();
		this.entity.persist(permiso);
		this.entity.getTransaction().commit();

	}

	@Override
	public void ActualizarPermiso(Permiso permiso) {
		this.entity.getTransaction().begin();
		this.entity.persist(permiso);
		this.entity.getTransaction().commit();

	}

	@Override
	public void EliminarPermiso(int idPermiso) {
		Permiso permiso = new Permiso();
		permiso =this.entity.find(Permiso.class, idPermiso);
		
		this.entity.getTransaction().begin();
		this.entity.remove(permiso);
		this.entity.getTransaction().commit();

	}

}
