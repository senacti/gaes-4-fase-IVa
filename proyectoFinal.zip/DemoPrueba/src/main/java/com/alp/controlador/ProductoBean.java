package com.alp.controlador;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;

import com.alp.imp.ProductoImp;
import com.alp.modelo.Producto;

@ManagedBean (name="productoBean")
@RequestScoped
public class ProductoBean {
Producto producto = new Producto();
	
	List<Producto> listaProducto = new ArrayList<Producto>();
	
	private Map<String,Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();		
	
	
	public Producto getProducto() {
		return producto;
	}

	public void setProducto(Producto producto) {
		this.producto = producto;
	}

	public List<Producto> getListaProducto() {
		return listaProducto;
	}

	public void setListaProducto(List<Producto> listaProducto) {
		this.listaProducto = listaProducto;
	}

	public Map<String, Object> getSessionMap() {
		return sessionMap;
	}

	public void setSessionMap(Map<String, Object> sessionMap) {
		this.sessionMap = sessionMap;
	}

	public List<Producto> findAll(){
		
		ProductoImp productoImp = new ProductoImp();
		this.listaProducto=  productoImp.findAll();
		return this.listaProducto;
	}

	public String crear(Producto producto) {
		ProductoImp productoImp = new ProductoImp();
		productoImp.CrearProducto(producto);
		return "/producto/lista.xhtml?faces-redirect=true";
	}
	
    public String findById(int idProducto) {
		System.out.print("Entro a crear"+ idProducto );
		ProductoImp productoImp = new ProductoImp();
		producto = productoImp.findById(idProducto);
		this.sessionMap.put("producto", producto);
		return "/producto/editar.xhtml?faces-redirect=true";
    	
    }
    
	public String actualizar (Producto producto) {
		System.out.print("Ha entrado a EDITAR");
    	ProductoImp productoImp = new ProductoImp();
        productoImp.ActualizarProducto(producto);
        return "/producto/lista.xhtml?faces-redirect=true";
    }
	
	public String eliminar (int idProducto) {
		ProductoImp productoImp = new ProductoImp();
		productoImp.EliminarProducto(idProducto);
		System.out.print("Ha ELIMINADO");
		return "/producto/lista.xhtml?faces-redirect=true";
	}

}