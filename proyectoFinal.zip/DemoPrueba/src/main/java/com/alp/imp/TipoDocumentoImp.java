package com.alp.imp;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.alp.fachada.ITipoDocumento;
import com.alp.modelo.TipoDocumento;
import com.alp.utilities.JPAUtil;

public class TipoDocumentoImp implements ITipoDocumento {

	EntityManager entity = JPAUtil.getEntityManagerFactory().createEntityManager();
	@Override
	public List<TipoDocumento> findAll() {
		this.entity.getTransaction().begin();	
		List<TipoDocumento> listaTipodocumento= new ArrayList<>();
		Query q = this.entity.createQuery("SELECT td FROM TipoDocumento td");
		listaTipodocumento = q.getResultList();
		this.entity.getTransaction();
		return listaTipodocumento;
	}

	@Override
	public TipoDocumento findById(int idDoc) {
		this.entity.getTransaction().begin();	
		TipoDocumento tipodocumento = new TipoDocumento();
		tipodocumento= this.entity.find(TipoDocumento.class, idDoc);
		
		return tipodocumento;
	}

	@Override
	public void CrearTipodocumento(TipoDocumento tipodocumento) {
		this.entity.getTransaction().begin();
		this.entity.persist(tipodocumento);
		this.entity.getTransaction().commit();

	}

	@Override
	public void ActualizarTipodocumento(TipoDocumento tipodocumento) {
		this.entity.getTransaction().begin();
		this.entity.merge(tipodocumento);
		this.entity.getTransaction().commit();


	}

	@Override
	public void EliminarTipodocumento(int idDoc) {
		TipoDocumento tipodocumento = new TipoDocumento();
		tipodocumento =this.entity.find(TipoDocumento.class, idDoc);
		
		this.entity.getTransaction().begin();
		this.entity.remove(tipodocumento);
		this.entity.getTransaction().commit();

	}

}
