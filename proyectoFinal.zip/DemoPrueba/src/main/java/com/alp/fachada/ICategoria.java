package com.alp.fachada;

import java.util.List;

import com.alp.modelo.Categoria;

public interface ICategoria {
	public List<Categoria> findAll();
	public Categoria findById (int idCategoria);
	public void CrearCategoria (Categoria categoria);
	public void ActualizarCategoria (Categoria categoria);
	public void EliminarCategoria (int idCategoria);

}
