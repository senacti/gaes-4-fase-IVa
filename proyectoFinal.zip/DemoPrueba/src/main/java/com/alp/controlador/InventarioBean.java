package com.alp.controlador;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;

import com.alp.imp.InventarioImp;
import com.alp.modelo.Inventario;

@ManagedBean (name="inventarioBean")
@RequestScoped
public class InventarioBean {
Inventario inventario = new Inventario();
	
	List<Inventario> listaInventario = new ArrayList<Inventario>();
	
	private Map<String,Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();		
	
	
	public Inventario getInventario() {
		return inventario;
	}

	public void setInventario(Inventario inventario) {
		this.inventario = inventario;
	}

	public List<Inventario> getListaInventario() {
		return listaInventario;
	}

	public void setListaInventario(List<Inventario> listaInventario) {
		this.listaInventario = listaInventario;
	}

	public Map<String, Object> getSessionMap() {
		return sessionMap;
	}

	public void setSessionMap(Map<String, Object> sessionMap) {
		this.sessionMap = sessionMap;
	}

	public List<Inventario> findAll(){
		
		InventarioImp inventarioImp = new InventarioImp();
		this.listaInventario=  inventarioImp.findAll();
		return this.listaInventario;
	}

	public String crear(Inventario inventario) {
		InventarioImp inventarioImp = new InventarioImp();
		inventarioImp.CrearInventario(inventario);
		return "/inventario/lista.xhtml?faces-redirect=true";
	}
	
    public String findById(int idInventario) {
		System.out.print("Entro a crear"+ idInventario );
		InventarioImp inventarioImp = new InventarioImp();
		inventario = inventarioImp.findById(idInventario);
		this.sessionMap.put("inventario", inventario);
		return "/inventario/editar.xhtml?faces-redirect=true";
    	
    }
    
	public String actualizar (Inventario inventario) {
		System.out.print("Ha entrado a EDITAR");
    	InventarioImp inventarioImp = new InventarioImp();
        inventarioImp.ActualizarInventario(inventario);
        return "/inventario/lista.xhtml?faces-redirect=true";
    }
	
	public String eliminar (int idInventario) {
		InventarioImp inventarioImp = new InventarioImp();
		inventarioImp.EliminarInventario(idInventario);
		System.out.print("Ha ELIMINADO");
		return "/inventario/lista.xhtml?faces-redirect=true";
	}

}