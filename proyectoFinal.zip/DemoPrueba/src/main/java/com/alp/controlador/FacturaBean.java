package com.alp.controlador;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;

import com.alp.imp.FacturaImp;
import com.alp.modelo.Factura;

@ManagedBean (name="facturaBean")
@RequestScoped
public class FacturaBean {
Factura factura = new Factura();
	
	List<Factura> listaFactura = new ArrayList<Factura>();
	
	private Map<String,Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();		
	
	
	public Factura getFactura() {
		return factura;
	}

	public void setFactura(Factura factura) {
		this.factura = factura;
	}

	public List<Factura> getListaFactura() {
		return listaFactura;
	}

	public void setListaFactura(List<Factura> listaFactura) {
		this.listaFactura = listaFactura;
	}

	public Map<String, Object> getSessionMap() {
		return sessionMap;
	}

	public void setSessionMap(Map<String, Object> sessionMap) {
		this.sessionMap = sessionMap;
	}

	public List<Factura> findAll(){
		
		FacturaImp facturaImp = new FacturaImp();
		this.listaFactura=  facturaImp.findAll();
		return this.listaFactura;
	}

	public String crear(Factura factura) {
		FacturaImp facturaImp = new FacturaImp();
		facturaImp.CrearFactura(factura);
		return "/factura/lista.xhtml?faces-redirect=true";
	}
	
    public String findById(int idFactura) {
		System.out.print("Entro a crear"+ idFactura );
		FacturaImp facturaImp = new FacturaImp();
		factura = facturaImp.findById(idFactura);
		this.sessionMap.put("factura", factura);
		return "/factura/editar.xhtml?faces-redirect=true";
    	
    }
    
	public String actualizar (Factura factura) {
		System.out.print("Ha entrado a EDITAR");
    	FacturaImp facturaImp = new FacturaImp();
        facturaImp.ActualizarFactura(factura);
        return "/factura/lista.xhtml?faces-redirect=true";
    }
	
	public String eliminar (int idFactura) {
		FacturaImp facturaImp = new FacturaImp();
		facturaImp.EliminarFactura(idFactura);
		System.out.print("Ha ELIMINADO");
		return "/factura/lista.xhtml?faces-redirect=true";
	}

}
