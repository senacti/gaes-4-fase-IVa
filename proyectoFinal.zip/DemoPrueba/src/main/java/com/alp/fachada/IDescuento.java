package com.alp.fachada;

import java.util.List;

import com.alp.modelo.Descuento;

public interface IDescuento {
	public List<Descuento> findAll();
	public Descuento findById (int idDescuento);
	public void CrearDescuento(Descuento descuento);
	public void ActualizarDescuento(Descuento descuento);
	public void EliminarDescuento (int idDescuento);

}
