package com.alp.imp;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.alp.fachada.IFactura;
import com.alp.modelo.CarroCompra;
import com.alp.modelo.Factura;
import com.alp.utilities.JPAUtil;

public class FacturaImp implements IFactura {

	EntityManager entity = JPAUtil.getEntityManagerFactory().createEntityManager();
	@Override
	public List<Factura> findAll() {
		this.entity.getTransaction().begin();	
		List<Factura> listaFactura= new ArrayList<>();
		Query q = this.entity.createQuery("SELECT ff FROM Factura ff");
		listaFactura = q.getResultList();
		this.entity.getTransaction();
		return listaFactura;
	}

	@Override
	public Factura findById(int idFactura) {
		this.entity.getTransaction().begin();	
		Factura factura = new Factura();
		factura= this.entity.find(Factura.class, idFactura);
		
		return factura;
	}

	@Override
	public void CrearFactura(Factura factura) {
		this.entity.getTransaction().begin();
		this.entity.persist(factura);
		this.entity.getTransaction().commit();

	}

	@Override
	public void ActualizarFactura(Factura factura) {
		this.entity.getTransaction().begin();
		this.entity.persist(factura);
		this.entity.getTransaction().commit();

	}

	@Override
	public void EliminarFactura(int idFactura) {
		Factura factura = new Factura();
		factura =this.entity.find(Factura.class, idFactura);
		
		this.entity.getTransaction().begin();
		this.entity.remove(factura);
		this.entity.getTransaction().commit();

	}

}
