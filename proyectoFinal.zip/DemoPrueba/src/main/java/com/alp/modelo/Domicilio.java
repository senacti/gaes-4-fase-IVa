package com.alp.modelo;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "domicilios")
public class Domicilio implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	private int idDomicilio;
	@Column(name = "descripcion", length = 45)
	private String descripcion;

	@ManyToOne
	@JoinColumn(name = "idCarro")
	private CarroCompra idCarro;

	@OneToMany(targetEntity = DetalleDomicilio.class, mappedBy = "idDomicilio")
	private List<DetalleDomicilio> listaDetalleDomicilio;

	public int getIdDomicilio() {
		return idDomicilio;
	}

	public void setIdDomicilio(int idDomicilio) {
		this.idDomicilio = idDomicilio;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public CarroCompra getIdCarroFk() {
		return idCarro;
	}

	public void setIdCarroFk(CarroCompra idCarro) {
		this.idCarro = idCarro;
	}

	public List<DetalleDomicilio> getListaDetalleDomicilio() {
		return listaDetalleDomicilio;
	}

	public void setListaDetalleDomicilio(List<DetalleDomicilio> listaDetalleDomicilio) {
		this.listaDetalleDomicilio = listaDetalleDomicilio;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
