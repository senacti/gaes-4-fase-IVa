package com.alp.fachada;

import java.util.List;

import com.alp.modelo.Factura;

public interface IFactura {
	public List<Factura> findAll();
	public Factura findById (int idFactura);
	public void CrearFactura (Factura factura);
	public void ActualizarFactura (Factura factura);
	public void EliminarFactura (int idFactura);

}
