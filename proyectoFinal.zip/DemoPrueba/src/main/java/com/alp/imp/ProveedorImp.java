package com.alp.imp;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.alp.fachada.IProveedor;
import com.alp.modelo.CarroCompra;
import com.alp.modelo.Proveedor;
import com.alp.utilities.JPAUtil;

public class ProveedorImp implements IProveedor {
	EntityManager entity = JPAUtil.getEntityManagerFactory().createEntityManager();
	@Override
	public List<Proveedor> findAll() {
		this.entity.getTransaction().begin();	
		List<Proveedor> listaProveedor= new ArrayList<>();
		Query q = this.entity.createQuery("SELECT pv FROM Proveedor pv");
		listaProveedor = q.getResultList();
		this.entity.getTransaction();
		return listaProveedor;
	}

	@Override
	public Proveedor findById(int idProveedor) {
		this.entity.getTransaction().begin();	
		Proveedor proveedor = new Proveedor();
		proveedor= this.entity.find(Proveedor.class, idProveedor);
		
		return proveedor;
	}

	@Override
	public void CrearProvedor(Proveedor provedor) {
		this.entity.getTransaction().begin();
		this.entity.persist(provedor);
		this.entity.getTransaction().commit();

	}

	@Override
	public void ActualizarProvedor(Proveedor provedor) {
		this.entity.getTransaction().begin();
		this.entity.persist(provedor);
		this.entity.getTransaction().commit();

	}

	@Override
	public void EliminarProvedor(int idProveedor) {
		Proveedor proveedor= new Proveedor();
		proveedor =this.entity.find(Proveedor.class, idProveedor);
		
		this.entity.getTransaction().begin();
		this.entity.remove(proveedor);
		this.entity.getTransaction().commit();

	}

}
