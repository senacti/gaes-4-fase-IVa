package com.alp.controlador;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;

import com.alp.imp.DomicilioImp;
import com.alp.modelo.Domicilio;

@ManagedBean (name="domicilioBean")
@RequestScoped
public class DomicilioBean {
Domicilio domicilio = new Domicilio();
	
	List<Domicilio> listaDomicilio = new ArrayList<Domicilio>();
	
	private Map<String,Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();		
	
	
	public Domicilio getDomicilio() {
		return domicilio;
	}

	public void setDomicilio(Domicilio domicilio) {
		this.domicilio = domicilio;
	}

	public List<Domicilio> getListaDomicilio() {
		return listaDomicilio;
	}

	public void setListaDomicilio(List<Domicilio> listaDomicilio) {
		this.listaDomicilio = listaDomicilio;
	}

	public Map<String, Object> getSessionMap() {
		return sessionMap;
	}

	public void setSessionMap(Map<String, Object> sessionMap) {
		this.sessionMap = sessionMap;
	}

	public List<Domicilio> findAll(){
		
		DomicilioImp domicilioImp = new DomicilioImp();
		this.listaDomicilio=  domicilioImp.findAll();
		return this.listaDomicilio;
	}

	public String crear(Domicilio domicilio) {
		DomicilioImp domicilioImp = new DomicilioImp();
		domicilioImp.CrearDomicilio(domicilio);
		return "/domicilio/lista.xhtml?faces-redirect=true";
	}
	
    public String findById(int idDomicilio) {
		System.out.print("Entro a crear"+ idDomicilio);
		DomicilioImp domicilioImp = new DomicilioImp();
		domicilio = domicilioImp.findById(idDomicilio);
		this.sessionMap.put("domicilio", domicilio);
		return "/domicilio/editar.xhtml?faces-redirect=true";
    	
    }
    
	public String actualizar (Domicilio domicilio) {
		System.out.print("Ha entrado a EDITAR");
    	DomicilioImp domicilioImp = new DomicilioImp();
        domicilioImp.ActualizarDomicilio(domicilio);
        return "/domicilio/lista.xhtml?faces-redirect=true";
    }
	
	public String eliminar (int idDomicilio) {
		DomicilioImp domicilioImp = new DomicilioImp();
		domicilioImp.EliminarDomicilio(idDomicilio);
		System.out.print("Ha ELIMINADO");
		return "/domicilio/lista.xhtml?faces-redirect=true";
	}

}