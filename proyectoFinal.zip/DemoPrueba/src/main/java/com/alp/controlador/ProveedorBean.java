package com.alp.controlador;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;

import com.alp.imp.ProveedorImp;
import com.alp.modelo.Proveedor;

@ManagedBean (name="proveedorBean")
@RequestScoped
public class ProveedorBean {
Proveedor proveedor = new Proveedor();
	
	List<Proveedor> listaProveedor = new ArrayList<Proveedor>();
	
	private Map<String,Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();		
	
	
	public Proveedor getProveedor() {
		return proveedor;
	}

	public void setProveedor(Proveedor proveedor) {
		this.proveedor = proveedor;
	}

	public List<Proveedor> getListaProveedor() {
		return listaProveedor;
	}

	public void setListaProveedor(List<Proveedor> listaProveedor) {
		this.listaProveedor = listaProveedor;
	}

	public Map<String, Object> getSessionMap() {
		return sessionMap;
	}

	public void setSessionMap(Map<String, Object> sessionMap) {
		this.sessionMap = sessionMap;
	}

	public List<Proveedor> findAll(){
		
		ProveedorImp proveedorImp = new ProveedorImp();
		this.listaProveedor=  proveedorImp.findAll();
		return this.listaProveedor;
	}

	public String crear(Proveedor proveedor) {
		ProveedorImp proveedorImp = new ProveedorImp();
		proveedorImp.CrearProvedor(proveedor);
		return "/proveedor/lista.xhtml?faces-redirect=true";
	}
	
    public String findById(int idProveedor) {
		System.out.print("Entro a crear"+ idProveedor );
		ProveedorImp proveedorImp = new ProveedorImp();
		proveedor = proveedorImp.findById(idProveedor);
		this.sessionMap.put("proveedor", proveedor);
		return "/proveedor/editar.xhtml?faces-redirect=true";
    	
    }
    
	public String actualizar (Proveedor proveedor) {
		System.out.print("Ha entrado a EDITAR");
    	ProveedorImp proveedorImp = new ProveedorImp();
        proveedorImp.ActualizarProvedor(proveedor);
        return "/proveedor/lista.xhtml?faces-redirect=true";
    }
	
	public String eliminar (int idProveedor) {
		ProveedorImp proveedorImp = new ProveedorImp();
		proveedorImp.EliminarProvedor(idProveedor);
		System.out.print("Ha ELIMINADO");
		return "/proveedor/lista.xhtml?faces-redirect=true";
	}

}