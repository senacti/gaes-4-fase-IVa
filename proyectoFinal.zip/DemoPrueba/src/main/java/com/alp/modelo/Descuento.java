package com.alp.modelo;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "descuentos")
public class Descuento implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	private int idDescuento;
	@Column(name = "valorDescuento", length = 45)
	private String valorDescuento;
	@Column(name = "fechaDescuento", length = 45)
	private String fechaDescuento;

	@OneToMany(targetEntity = Producto.class, mappedBy = "idDescuento")
	private List<Producto> listaProducto;

	public int getIdDescuento() {
		return idDescuento;
	}

	public void setIdDescuento(int idDescuento) {
		this.idDescuento = idDescuento;
	}

	public String getValorDescuento() {
		return valorDescuento;
	}

	public void setValorDescuento(String valorDescuento) {
		this.valorDescuento = valorDescuento;
	}

	public String getFechaDescuento() {
		return fechaDescuento;
	}

	public void setFechaDescuento(String fechaDescuento) {
		this.fechaDescuento = fechaDescuento;
	}

	public List<Producto> getListaProducto() {
		return listaProducto;
	}

	public void setListaProducto(List<Producto> listaProducto) {
		this.listaProducto = listaProducto;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
