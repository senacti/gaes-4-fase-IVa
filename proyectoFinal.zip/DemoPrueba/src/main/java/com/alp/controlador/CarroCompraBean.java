package com.alp.controlador;

import java.util.ArrayList;

import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;

import com.alp.imp.CarroCompraImp;
import com.alp.modelo.CarroCompra;

@ManagedBean (name="carrocompraBean")
@RequestScoped
public class CarroCompraBean {
	CarroCompra carrocompra = new CarroCompra();
	
	List<CarroCompra> listaCarroCompra = new ArrayList<CarroCompra>();
	
	private Map<String,Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();

	public CarroCompra getCarrocompra() {
		return carrocompra;
	}

	public void setCarrocompra(CarroCompra carrocompra) {
		this.carrocompra = carrocompra;
	}

	public List<CarroCompra> getListaCarroCompra() {
		return listaCarroCompra;
	}

	public void setListaCarroCompra(List<CarroCompra> listaCarroCompra) {
		this.listaCarroCompra = listaCarroCompra;
	}

	public Map<String, Object> getSessionMap() {
		return sessionMap;
	}

	public void setSessionMap(Map<String, Object> sessionMap) {
		this.sessionMap = sessionMap;
	}		
public List<CarroCompra> findAll(){
		
	    CarroCompraImp carrocompraImp = new CarroCompraImp();
		this.listaCarroCompra=  carrocompraImp.findAll();
		return this.listaCarroCompra;
	}

	public String crear(CarroCompra carrocompra) {
		CarroCompraImp carrocompraImp = new CarroCompraImp();
		carrocompraImp.CrearCarroCompra(carrocompra);
		return "/carrocompra/lista.xhtml?faces-redirect=true";
	}
	
    public String findById(int idCarro) {
		System.out.print("Entro a crear"+ idCarro );
		CarroCompraImp carrocompraImp = new CarroCompraImp();
		carrocompra = carrocompraImp.findById(idCarro);
		this.sessionMap.put("carrocompra", carrocompra);
		return "/carrocompra/editar.xhtml?faces-redirect=true";
    	
    }
    
	public String actualizar (CarroCompra carrocompra) {
		System.out.print("Ha entrado a EDITAR");
		CarroCompraImp carrocompraImp = new CarroCompraImp();
		carrocompraImp.ActualizarCarroCompra(carrocompra);
        return "/carrocompra/lista.xhtml?faces-redirect=true";
    }
	
	public String eliminar (int idCarro) {
		CarroCompraImp carrocompraImp = new CarroCompraImp();
		carrocompraImp.EliminarCarroCompra(idCarro);
		System.out.print("Ha ELIMINADO");
		return "/CarroCompra/lista.xhtml?faces-redirect=true";
	}


}
