package com.alp.fachada;

import java.util.List;

import com.alp.modelo.DetalleDomicilio;

public interface IDetalleDomicilio {
	public List<DetalleDomicilio> findAll();
	public DetalleDomicilio findById (int id);
	public void CrearDetalledomicilio (DetalleDomicilio detalledomicilio);
	public void ActualizarDetalledomicilio (DetalleDomicilio detalledomicilio);
	public void EliminarDetalledomicilio (int id);

}
