package com.alp.imp;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.alp.fachada.IDetalleDomicilio;
import com.alp.modelo.CarroCompra;
import com.alp.modelo.DetalleDomicilio;
import com.alp.utilities.JPAUtil;

public class DetalleDomicilioImp implements IDetalleDomicilio {

	EntityManager entity = JPAUtil.getEntityManagerFactory().createEntityManager();
	@Override
	public List<DetalleDomicilio> findAll() {
		this.entity.getTransaction().begin();	
		List<DetalleDomicilio> listaDetalleDomicilio= new ArrayList<>();
		Query q = this.entity.createQuery("SELECT dc FROM DetalleDomicilio dc");
		listaDetalleDomicilio = q.getResultList();
		this.entity.getTransaction();
		return listaDetalleDomicilio;
	}

	@Override
	public DetalleDomicilio findById(int id) {
		this.entity.getTransaction().begin();	
		DetalleDomicilio detalledomicilio = new DetalleDomicilio();
		detalledomicilio= this.entity.find(DetalleDomicilio.class, id);
		
		return detalledomicilio;
	}

	@Override
	public void CrearDetalledomicilio(DetalleDomicilio detalledomicilio) {
		this.entity.getTransaction().begin();
		this.entity.persist(detalledomicilio);
		this.entity.getTransaction().commit();

	}

	@Override
	public void ActualizarDetalledomicilio(DetalleDomicilio detalledomicilio) {
		this.entity.getTransaction().begin();
		this.entity.persist(detalledomicilio);
		this.entity.getTransaction().commit();

	}

	@Override
	public void EliminarDetalledomicilio(int id) {
		DetalleDomicilio detalledomicilio = new DetalleDomicilio();
		detalledomicilio =this.entity.find(DetalleDomicilio.class, id);
		
		this.entity.getTransaction().begin();
		this.entity.remove(detalledomicilio);
		this.entity.getTransaction().commit();

	}

}
