package com.alp.fachada;

import java.util.List;

import com.alp.modelo.Usuario;

public interface IUsuario {
	public List<Usuario> findAll();
	public Usuario findById (int idUsuario);
	public void CrearUsuario (Usuario usuario);
	public void ActualizarUsuario(Usuario usuario);
	public void EliminarUsuario (int idUsuario);

}
