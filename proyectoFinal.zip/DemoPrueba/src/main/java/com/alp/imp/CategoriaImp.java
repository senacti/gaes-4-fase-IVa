package com.alp.imp;

import java.util.ArrayList;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.alp.fachada.ICategoria;
import com.alp.modelo.Categoria;
import com.alp.utilities.JPAUtil;

public class CategoriaImp implements ICategoria {

	EntityManager entity = JPAUtil.getEntityManagerFactory().createEntityManager();
	@Override
	public List<Categoria> findAll() {
		this.entity.getTransaction().begin();	
		List<Categoria> listaCategoria= new ArrayList<>();
		Query q = this.entity.createQuery("SELECT ca FROM Categoria ca");
		listaCategoria = q.getResultList();
		this.entity.getTransaction();
		return listaCategoria;
	}

	@Override
	public Categoria findById(int idCategoria) {
		this.entity.getTransaction().begin();	
		Categoria categoria = new Categoria();
		categoria= this.entity.find(Categoria.class, idCategoria);
		
		return categoria;
	}

	@Override
	public void CrearCategoria(Categoria categoria) {
		this.entity.getTransaction().begin();
		this.entity.persist(categoria);
		this.entity.getTransaction().commit();

	}

	@Override
	public void ActualizarCategoria(Categoria categoria) {
		this.entity.getTransaction().begin();
		this.entity.merge(categoria);
		this.entity.getTransaction().commit();

	}

	@Override
	public void EliminarCategoria(int idCategoria) {
		Categoria categoria = new Categoria();
		categoria =this.entity.find(Categoria.class, idCategoria);
		
		this.entity.getTransaction().begin();
		this.entity.remove(categoria);
		this.entity.getTransaction().commit();

	}

}
