package com.alp.fachada;

import java.util.List;

import com.alp.modelo.Rol;

public interface IRol {
	public List<Rol> findAll();
	public Rol findById (int idRol);
	public void CrearRol (Rol rol);
	public void ActualizarRol (Rol rol);
	public void EliminarRol (int idRol);

}
