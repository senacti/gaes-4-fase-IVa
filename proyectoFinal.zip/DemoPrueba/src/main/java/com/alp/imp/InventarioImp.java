package com.alp.imp;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.alp.fachada.IInventario;
import com.alp.modelo.CarroCompra;
import com.alp.modelo.Inventario;
import com.alp.utilities.JPAUtil;

public class InventarioImp implements IInventario {
	EntityManager entity = JPAUtil.getEntityManagerFactory().createEntityManager();
	@Override
	public List<Inventario> findAll() {
		this.entity.getTransaction().begin();	
		List<Inventario> listaInventario= new ArrayList<>();
		Query q = this.entity.createQuery("SELECT ii FROM Inventario ii");
		listaInventario = q.getResultList();
		this.entity.getTransaction();
		return listaInventario;
	}

	@Override
	public Inventario findById(int id) {
		this.entity.getTransaction().begin();	
		Inventario inventario = new Inventario();
		inventario= this.entity.find(Inventario.class, id);
		
		return inventario;
	}

	@Override
	public void CrearInventario(Inventario inventario) {
		this.entity.getTransaction().begin();
		this.entity.persist(inventario);
		this.entity.getTransaction().commit();

	}

	@Override
	public void ActualizarInventario(Inventario inventario) {
		this.entity.getTransaction().begin();
		this.entity.persist(inventario);
		this.entity.getTransaction().commit();

	}

	@Override
	public void EliminarInventario(int id) {
		Inventario inventario = new Inventario();
		inventario =this.entity.find(Inventario.class, id);
		
		this.entity.getTransaction().begin();
		this.entity.remove(inventario);
		this.entity.getTransaction().commit();

	}

}
