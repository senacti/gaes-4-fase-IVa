package com.alp.controlador;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;

import com.alp.imp.DetalleDomicilioImp;
import com.alp.modelo.DetalleDomicilio;

@ManagedBean (name="detalledomicilioBean")
@RequestScoped
public class DetalleDomicilioBean {
DetalleDomicilio detalleDomicilio = new DetalleDomicilio();
	
	List<DetalleDomicilio> listaDetalleDomicilio = new ArrayList<DetalleDomicilio>();
	
	private Map<String,Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();		
	
	
	public DetalleDomicilio getDetalleDomicilio() {
		return detalleDomicilio;
	}

	public void setDetalleDomicilio(DetalleDomicilio detalleDomicilio) {
		this.detalleDomicilio = detalleDomicilio;
	}

	public List<DetalleDomicilio> getListaDetalleDomicilio() {
		return listaDetalleDomicilio;
	}

	public void setListaDetalleDomicilio(List<DetalleDomicilio> listaDetalleDomicilio) {
		this.listaDetalleDomicilio = listaDetalleDomicilio;
	}

	public Map<String, Object> getSessionMap() {
		return sessionMap;
	}

	public void setSessionMap(Map<String, Object> sessionMap) {
		this.sessionMap = sessionMap;
	}

	public List<DetalleDomicilio> findAll(){
		
		DetalleDomicilioImp detalleDomicilioImp = new DetalleDomicilioImp();
		this.listaDetalleDomicilio=  detalleDomicilioImp.findAll();
		return this.listaDetalleDomicilio;
	}

	public String crear(DetalleDomicilio detalleDomicilio) {
		DetalleDomicilioImp detalleDomicilioImp = new DetalleDomicilioImp();
		detalleDomicilioImp.CrearDetalledomicilio(detalleDomicilio);
		return "/detalleDomicilio/lista.xhtml?faces-redirect=true";
	}
	
    public String findById(int idDomicilio) {
		System.out.print("Entro a crear"+ idDomicilio );
		DetalleDomicilioImp detalleDomicilioImp = new DetalleDomicilioImp();
		detalleDomicilio = detalleDomicilioImp.findById(idDomicilio);
		this.sessionMap.put("detalleDomicilio", detalleDomicilio);
		return "/detalleDomicilio/editar.xhtml?faces-redirect=true";
    	
    }
    
	public String actualizar (DetalleDomicilio detalleDomicilio) {
		System.out.print("Ha entrado a EDITAR");
    	DetalleDomicilioImp detalleDomicilioImp = new DetalleDomicilioImp();
        detalleDomicilioImp.ActualizarDetalledomicilio(detalleDomicilio);
        return "/detalleDomicilio/lista.xhtml?faces-redirect=true";
    }
	
	public String eliminar (int idDomicilio) {
		DetalleDomicilioImp detalleDomicilioImp = new DetalleDomicilioImp();
		detalleDomicilioImp.EliminarDetalledomicilio(idDomicilio);
		System.out.print("Ha ELIMINADO");
		return "/detalleDomicilio/lista.xhtml?faces-redirect=true";
	}

}