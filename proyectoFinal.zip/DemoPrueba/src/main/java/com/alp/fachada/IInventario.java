package com.alp.fachada;

import java.util.List;

import com.alp.modelo.Inventario;

public interface IInventario {
	public List<Inventario> findAll();
	public Inventario findById (int id);
	public void CrearInventario(Inventario inventario);
	public void ActualizarInventario (Inventario inventario);
	public void EliminarInventario (int id);

}
