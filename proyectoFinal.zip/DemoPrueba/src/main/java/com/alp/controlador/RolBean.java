package com.alp.controlador;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;

import com.alp.imp.RolImp;
import com.alp.modelo.Rol;

@ManagedBean (name="rolBean")
@RequestScoped
public class RolBean {
Rol rol = new Rol();
	
	List<Rol> listaRol = new ArrayList<Rol>();
	
	private Map<String,Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();		
	
	
	public Rol getRol() {
		return rol;
	}

	public void setRol(Rol rol) {
		this.rol = rol;
	}

	public List<Rol> getListaRol() {
		return listaRol;
	}

	public void setListaRol(List<Rol> listaRol) {
		this.listaRol = listaRol;
	}

	public Map<String, Object> getSessionMap() {
		return sessionMap;
	}

	public void setSessionMap(Map<String, Object> sessionMap) {
		this.sessionMap = sessionMap;
	}

	public List<Rol> findAll(){
		
		RolImp rolImp = new RolImp();
		this.listaRol=  rolImp.findAll();
		return this.listaRol;
	}

	public String crear(Rol rol) {
		RolImp rolImp = new RolImp();
		rolImp.CrearRol(rol);
		return "/rol/lista.xhtml?faces-redirect=true";
	}
	
    public String findById(int idRol) {
		System.out.print("Entro a crear"+ idRol );
		RolImp rolImp = new RolImp();
		rol = rolImp.findById(idRol);
		this.sessionMap.put("rol", rol);
		return "/rol/editar.xhtml?faces-redirect=true";
    	
    }
    
	public String actualizar (Rol rol) {
    	RolImp rolImp = new RolImp();
        rolImp.ActualizarRol(rol);
        System.out.print("Ha entrado a EDITAR");
        return "/rol/editar.xhtml?faces-redirect=true";
    }
	
	public String eliminar (int idRol) {
		RolImp rolImp = new RolImp();
		rolImp.EliminarRol(idRol);
		System.out.print("Ha ELIMINADO");
		return "/rol/lista.xhtml?faces-redirect=true";
	}

}