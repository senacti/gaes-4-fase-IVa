package com.alp.modelo;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "usuarios")
public class Usuario implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idUsuario;
	@Column(name = "pNombre", length = 45)
	private String pNombre;
	@Column(name = "sNombre", length = 35)
	private String sNombre;
	@Column(name = "pApellido", length = 35)
	private String pApellido;
	@Column(name = "sApellido", length = 35)
	private String sApellido;
	@Column(name = "correo", length = 50)
	private String correo;
	@Column(name = "contraseña", length = 45)
	private String contraseña;

	@ManyToOne
	@JoinColumn(name = "idRol")
	private Rol idRol;

	@ManyToOne
	@JoinColumn(name = "idDoc")
	private TipoDocumento idDoc;
	
    
	public int getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(int idUsuario) {
		this.idUsuario = idUsuario;
	}

	public String getpNombre() {
		return pNombre;
	}

	public void setpNombre(String pNombre) {
		this.pNombre = pNombre;
	}

	public String getsNombre() {
		return sNombre;
	}

	public void setsNombre(String sNombre) {
		this.sNombre = sNombre;
	}

	public String getpApellido() {
		return pApellido;
	}

	public void setpApellido(String pApellido) {
		this.pApellido = pApellido;
	}

	public String getsApellido() {
		return sApellido;
	}

	public void setsApellido(String sApellido) {
		this.sApellido = sApellido;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getContraseña() {
		return contraseña;
	}

	public void setContraseña(String contraseña) {
		this.contraseña = contraseña;
	}

	public Rol getIdRol() {
		return idRol;
	}

	public void setIdRolFk(Rol idRolFk) {
		this.idRol = idRol;
	}

	public TipoDocumento getIdDoc() {
		return idDoc;
	}

	public void setIdDocFK(TipoDocumento idDoc) {
		this.idDoc = idDoc;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	@OneToMany(targetEntity = CarroCompra.class, mappedBy = "idUsuario")
	private List<CarroCompra> listaCarroCompra;
	
	@OneToMany(targetEntity = Factura.class, mappedBy = "idUsuario")
	private List<Factura> listaFactura;
}
