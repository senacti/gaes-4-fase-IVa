package com.alp.fachada;

import java.util.List;

import com.alp.modelo.Producto;

public interface IProducto {
	public List<Producto> findAll();
	public Producto findById (int idProducto);
	public void CrearProducto (Producto producto);
	public void ActualizarProducto (Producto producto);
	public void EliminarProducto (int idProducto);

}
