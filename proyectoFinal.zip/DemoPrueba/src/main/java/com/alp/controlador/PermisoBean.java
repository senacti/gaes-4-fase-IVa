package com.alp.controlador;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;

import com.alp.imp.PermisoImp;
import com.alp.modelo.Permiso;

@ManagedBean (name="permisoBean")
@RequestScoped
public class PermisoBean {
Permiso permiso = new Permiso();
	
	List<Permiso> listaPermiso = new ArrayList<Permiso>();
	
	private Map<String,Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();		
	
	
	public Permiso getPermiso() {
		return permiso;
	}

	public void setPermiso(Permiso permiso) {
		this.permiso = permiso;
	}

	public List<Permiso> getListaPermiso() {
		return listaPermiso;
	}

	public void setListaPermiso(List<Permiso> listaPermiso) {
		this.listaPermiso = listaPermiso;
	}

	public Map<String, Object> getSessionMap() {
		return sessionMap;
	}

	public void setSessionMap(Map<String, Object> sessionMap) {
		this.sessionMap = sessionMap;
	}

	public List<Permiso> findAll(){
		
		PermisoImp permisoImp = new PermisoImp();
		this.listaPermiso=  permisoImp.findAll();
		return this.listaPermiso;
	}

	public String crear(Permiso permiso) {
		PermisoImp permisoImp = new PermisoImp();
		permisoImp.CrearPermiso(permiso);
		return "/permiso/lista.xhtml?faces-redirect=true";
	}
	
    public String findById(int idPermiso) {
		System.out.print("Entro a crear"+ idPermiso );
		PermisoImp permisoImp = new PermisoImp();
		permiso = permisoImp.findById(idPermiso);
		this.sessionMap.put("permiso", permiso);
		return "/permiso/editar.xhtml?faces-redirect=true";
    	
    }
    
	public String actualizar (Permiso permiso) {
		System.out.print("Ha entrado a EDITAR");
    	PermisoImp permisoImp = new PermisoImp();
        permisoImp.ActualizarPermiso(permiso);
        return "/permiso/lista.xhtml?faces-redirect=true";
    }
	
	public String eliminar (int idPermiso) {
		PermisoImp permisoImp = new PermisoImp();
		permisoImp.EliminarPermiso(idPermiso);
		System.out.print("Ha ELIMINADO");
		return "/permiso/lista.xhtml?faces-redirect=true";
	}

}