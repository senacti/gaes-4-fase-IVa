package com.alp.controlador;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;

import com.alp.imp.CategoriaImp;
import com.alp.modelo.Categoria;

@ManagedBean (name="categoriaBean")
@RequestScoped
public class CategoriaBean {
Categoria categoria = new Categoria();
	
	List<Categoria> listaCategoria = new ArrayList<Categoria>();
	
	private Map<String,Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();		
	
	
	public Categoria getCategoria() {
		return categoria;
	}

	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}

	public List<Categoria> getListaCategoria() {
		return listaCategoria;
	}

	public void setListaCategoria(List<Categoria> listaCategoria) {
		this.listaCategoria = listaCategoria;
	}

	public Map<String, Object> getSessionMap() {
		return sessionMap;
	}

	public void setSessionMap(Map<String, Object> sessionMap) {
		this.sessionMap = sessionMap;
	}

	public List<Categoria> findAll(){
		
		CategoriaImp categoriaImp = new CategoriaImp();
		this.listaCategoria=  categoriaImp.findAll();
		return this.listaCategoria;
	}

	public String crear(Categoria categoria) {
		CategoriaImp categoriaImp = new CategoriaImp();
		categoriaImp.CrearCategoria(categoria);
		return "/categoria/lista.xhtml?faces-redirect=true";
	}
	
    public String findById(int idCategoria) {
		System.out.print("Entro a crear"+ idCategoria );
		CategoriaImp categoriaImp = new CategoriaImp();
		categoria = categoriaImp.findById(idCategoria);
		this.sessionMap.put("categoria", categoria);
		return "/categoria/editar.xhtml?faces-redirect=true";
    	
    }
    
	public String actualizar (Categoria categoria) {
		System.out.print("Ha entrado a EDITAR");
    	CategoriaImp categoriaImp = new CategoriaImp();
        categoriaImp.ActualizarCategoria(categoria);
        return "/categoria/lista.xhtml?faces-redirect=true";
    }
	
	public String eliminar (int idCategoria) {
		CategoriaImp categoriaImp = new CategoriaImp();
		categoriaImp.EliminarCategoria(idCategoria);
		System.out.print("Ha ELIMINADO");
		return "/categoria/lista.xhtml?faces-redirect=true";
	}

}