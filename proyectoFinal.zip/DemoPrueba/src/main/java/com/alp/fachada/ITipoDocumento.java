package com.alp.fachada;

import java.util.List;

import com.alp.modelo.TipoDocumento;

public interface ITipoDocumento {
	public List<TipoDocumento> findAll();
	public TipoDocumento findById (int idDoc);
	public void CrearTipodocumento (TipoDocumento tipodocumento);
	public void ActualizarTipodocumento (TipoDocumento tipodocumento);
	public void EliminarTipodocumento (int idDoc);

}
