package com.alp.modelo;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "productos")
public class Producto implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	private int idProducto;
	@Column(name = "nombreProducto", length = 45)
	private String nombreProducto;
	@Column(name = "precioproducto", length = 45)
	private String precioproducto;
	@Column(name = "descripcion", length = 45)
	private String descripcion;

	@ManyToOne
	@JoinColumn(name = "idCategoria", referencedColumnName = "idCategoria")
	private Categoria idCategoria;

	@ManyToOne
	@JoinColumn(name = "idDescuento",referencedColumnName = "idDescuento")
	private Descuento idDescuento;

	@ManyToMany(mappedBy = "listaProducto", cascade = { CascadeType.MERGE })
	private List<CarroCompra> listaCarroCompra;

	@ManyToMany(cascade = { CascadeType.MERGE })
	@JoinTable(name = "rolproveedor", joinColumns = @JoinColumn(name = "idProducto", nullable = false), inverseJoinColumns = @JoinColumn(name = "idProveedor", nullable = false))
	private List<Proveedor> listaProveedor;

	@OneToMany(targetEntity = Inventario.class, mappedBy = "idProducto")
	private List<Inventario> listaInventario;

	public int getIdProducto() {
		return idProducto;
	}

	public void setIdProducto(int idProducto) {
		this.idProducto = idProducto;
	}

	public String getNombreProducto() {
		return nombreProducto;
	}

	public void setNombreProducto(String nombreProducto) {
		this.nombreProducto = nombreProducto;
	}

	public String getPrecioproducto() {
		return precioproducto;
	}

	public void setPrecioproducto(String precioproducto) {
		this.precioproducto = precioproducto;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Categoria getIdCategoriaFk() {
		return idCategoria;
	}

	public void setIdCategoriaFk(Categoria idCategoriaFk) {
		this.idCategoria = idCategoriaFk;
	}

	public Descuento getIdDescuentoFk() {
		return idDescuento;
	}

	public void setIdDescuentoFk(Descuento idDescuentoFk) {
		this.idDescuento = idDescuentoFk;
	}

	public List<CarroCompra> getListaCarroCompra() {
		return listaCarroCompra;
	}

	public void setListaCarroCompra(List<CarroCompra> listaCarroCompra) {
		this.listaCarroCompra = listaCarroCompra;
	}

	public List<Proveedor> getListaProveedor() {
		return listaProveedor;
	}

	public void setListaProveedor(List<Proveedor> listaProveedor) {
		this.listaProveedor = listaProveedor;
	}

	public List<Inventario> getListaInventario() {
		return listaInventario;
	}

	public void setListaInventario(List<Inventario> listaInventario) {
		this.listaInventario = listaInventario;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
