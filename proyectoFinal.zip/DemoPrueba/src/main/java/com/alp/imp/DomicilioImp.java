package com.alp.imp;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.alp.fachada.IDomicilio;
import com.alp.modelo.CarroCompra;
import com.alp.modelo.Domicilio;
import com.alp.utilities.JPAUtil;

public class DomicilioImp implements IDomicilio {

	EntityManager entity = JPAUtil.getEntityManagerFactory().createEntityManager();
	@Override
	public List<Domicilio> findAll() {
		this.entity.getTransaction().begin();	
		List<Domicilio> listaDomicilio= new ArrayList<>();
		Query q = this.entity.createQuery("SELECT dm FROM Domicilio dm");
		listaDomicilio = q.getResultList();
		this.entity.getTransaction();
		return listaDomicilio;
	}

	@Override
	public Domicilio findById(int idDomicilio) {
		this.entity.getTransaction().begin();	
		Domicilio domicilio = new Domicilio();
		domicilio= this.entity.find(Domicilio.class, idDomicilio);
		
		return domicilio;
	}

	@Override
	public void CrearDomicilio(Domicilio domicilio) {
		this.entity.getTransaction().begin();
		this.entity.persist(domicilio);
		this.entity.getTransaction().commit();

	}

	@Override
	public void ActualizarDomicilio(Domicilio domicilio) {
		this.entity.getTransaction().begin();
		this.entity.persist(domicilio);
		this.entity.getTransaction().commit();

	}

	@Override
	public void EliminarDomicilio(int idDomicilio) {
		Domicilio domicilio = new Domicilio();
		domicilio =this.entity.find(Domicilio.class, idDomicilio);
		
		this.entity.getTransaction().begin();
		this.entity.remove(domicilio);
		this.entity.getTransaction().commit();

	}

}
